export class LogInModel {
    username    ?: string;
    password    ?: string;
}