export interface UserModel {
    username ?: string,
    password ?: string;
    github ?: string ;
    linkedin ?: string;
    skills ?: string  [];
    classes ?: string [];
    name ?: string;
}



