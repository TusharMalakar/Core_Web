export class RegisterModel {
    username: String = '';
    password: String = '';
    password2: String = '';
}